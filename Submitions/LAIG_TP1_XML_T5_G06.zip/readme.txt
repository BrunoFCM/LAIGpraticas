Turma 05
Grupo 06
Bruno Filipe Cardoso Micaelo 201706044
Jo�o Pedro da Costa Ribeiro 201704851
